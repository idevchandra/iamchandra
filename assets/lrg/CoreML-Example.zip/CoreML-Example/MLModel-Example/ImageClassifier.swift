//
//  ImageClassifier.swift
//  MLModel-Example
//
//  Created by Chandra on 6/13/25.
//

import CoreML
import Vision
import UIKit

// MARK: - Image Classifier Class
class ImageClassifier {
    private var model: VNCoreMLModel?
    
    init() {
        setupModel()
    }
    
    private func setupModel() {
        // Using MobileNetV2 - make sure you have the .mlmodel file in your project
        guard let modelURL = Bundle.main.url(forResource: "MobileNetV2", withExtension: "mlmodelc"),
              let mlModel = try? MLModel(contentsOf: modelURL),
              let visionModel = try? VNCoreMLModel(for: mlModel) else {
            print("Failed to load MobileNetV2 model")
            return
        }
        self.model = visionModel
    }
    
    func classifyImage(_ image: UIImage, completion: @escaping (String?) -> Void) {
        guard let model = model,
              let ciImage = CIImage(image: image) else {
            completion(nil)
            return
        }
        
        let request = VNCoreMLRequest(model: model) { request, error in
            guard let results = request.results as? [VNClassificationObservation],
                  let topResult = results.first else {
                completion(nil)
                return
            }
            
            let prediction = "\(topResult.identifier) (\(Int(topResult.confidence * 100))%)"
            DispatchQueue.main.async {
                completion(prediction)
            }
        }
        
        let handler = VNImageRequestHandler(ciImage: ciImage)
        DispatchQueue.global(qos: .userInitiated).async {
            try? handler.perform([request])
        }
    }
}

// MARK: - Alternative Usage Examples

// Example 1: Simple usage in any view controller
class SimpleUsageExample: UIViewController {
    let classifier = ImageClassifier()
    
    func classifyExampleImage() {
        // Assuming you have an image
        let image = UIImage(named: "sample_image") // Replace with your image
        
        classifier.classifyImage(image!) { result in
            if let prediction = result {
                print("Classification result: \(prediction)")
            } else {
                print("Classification failed")
            }
        }
    }
}

// Example 2: Using with async/await (iOS 15+)
extension ImageClassifier {
    func classifyImage(_ image: UIImage) async -> String? {
        return await withCheckedContinuation { continuation in
            classifyImage(image) { result in
                continuation.resume(returning: result)
            }
        }
    }
}

class AsyncUsageExample: UIViewController {
    let classifier = ImageClassifier()
    
    func classifyWithAsync() async {
        guard let image = UIImage(named: "sample_image") else { return }
        
        let result = await classifier.classifyImage(image)
        
        // Update UI on main thread
        await MainActor.run {
            if let prediction = result {
                print("Async classification result: \(prediction)")
            } else {
                print("Async classification failed")
            }
        }
    }
}

// Example 3: Batch processing multiple images
extension ImageClassifier {
    func classifyImages(_ images: [UIImage], completion: @escaping ([String?]) -> Void) {
        let group = DispatchGroup()
        var results: [String?] = Array(repeating: nil, count: images.count)
        
        for (index, image) in images.enumerated() {
            group.enter()
            classifyImage(image) { result in
                results[index] = result
                group.leave()
            }
        }
        
        group.notify(queue: .main) {
            completion(results)
        }
    }
}

class BatchProcessingExample: UIViewController {
    let classifier = ImageClassifier()
    
    func classifyMultipleImages() {
        let images = [
            UIImage(named: "image1"),
            UIImage(named: "image2"),
            UIImage(named: "image3")
        ].compactMap { $0 }
        
        classifier.classifyImages(images) { results in
            for (index, result) in results.enumerated() {
                if let prediction = result {
                    print("Image \(index + 1): \(prediction)")
                } else {
                    print("Image \(index + 1): Classification failed")
                }
            }
        }
    }
}
