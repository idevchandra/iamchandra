//
//  ViewController.swift
//  MLModel-Example
//
//  Created by Chandra on 6/13/25.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: - IBOutlets
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var selectImageButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    // MARK: - Properties
    private let imageClassifier = ImageClassifier()
    private var selectedImage: UIImage?
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
        
    }
    private func setupUI() {
        // Setup image view
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = UIColor.systemGray6
        imageView.layer.cornerRadius = 8
        imageView.clipsToBounds = true
        
        // Setup buttons
        selectImageButton.setTitle("Select Image", for: .normal)
        
        // Setup result label
        resultLabel.text = "Select an image to classify"
        resultLabel.textAlignment = .center
        resultLabel.numberOfLines = 0
        
        // Setup activity indicator
        activityIndicator.hidesWhenStopped = true
        
        // Setup Label
        resultLabel.textColor = .label
    }
    
    // MARK: - IBActions
    @IBAction func selectImageButtonTapped(_ sender: UIButton) {
        presentImagePicker()
    }
    
    func classifyImage() {
        guard let image = selectedImage else { return }
        
        // Show loading state
        activityIndicator.startAnimating()
        resultLabel.text = "Classifying..."
        
        // Classify the image
        imageClassifier.classifyImage(image) { [weak self] result in
            DispatchQueue.main.async {
                self?.handleClassificationResult(result)
            }
        }
    }
    
    // MARK: - Helper Methods
    private func presentImagePicker() {
        let alertController = UIAlertController(title: "Select Image", message: nil, preferredStyle: .actionSheet)
        
        // Camera option
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let cameraAction = UIAlertAction(title: "Camera", style: .default) { _ in
                self.presentImagePicker(sourceType: .camera)
            }
            alertController.addAction(cameraAction)
        }
        
        // Photo Library option
        let libraryAction = UIAlertAction(title: "Photo Library", style: .default) { _ in
            self.presentImagePicker(sourceType: .photoLibrary)
        }
        alertController.addAction(libraryAction)
        
        // Cancel option
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        alertController.addAction(cancelAction)
        
        // For iPad
        if let popover = alertController.popoverPresentationController {
            popover.sourceView = selectImageButton
            popover.sourceRect = selectImageButton.bounds
        }
        
        present(alertController, animated: true)
    }
    
    private func presentImagePicker(sourceType: UIImagePickerController.SourceType) {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = sourceType
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true)
    }
    
    private func handleClassificationResult(_ result: String?) {
        activityIndicator.stopAnimating()
        
        if let result = result {
            resultLabel.text = "Prediction: \(result)"
            resultLabel.textColor = .white
        } else {
            resultLabel.text = "Failed to classify image"
            resultLabel.textColor = .systemRed
        }
    }
}

// MARK: - UIImagePickerControllerDelegate
extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let image = info[.editedImage] as? UIImage ?? info[.originalImage] as? UIImage
        
        if let selectedImage = image {
            self.selectedImage = selectedImage
            imageView.image = selectedImage
        }
        
        picker.dismiss(animated: true) {
            self.classifyImage()
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
}
